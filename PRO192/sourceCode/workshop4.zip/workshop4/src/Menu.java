
public class Menu {

	void main_menu() {
		System.out.println("1. Import");
		System.out.println("2. Find");
		System.out.println("3. Insert");
		System.out.println("4. Update");
		System.out.println("5. Delete");
		System.out.println("6. Export");
		System.out.println("7. Exit");
	}

}
