package Project2;

public class Student {
    String sID, sName;

    public String toString() {
        return sID + ": " + sName;
    }
}
