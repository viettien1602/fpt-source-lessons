package Project2;

public class Vaccine {
    String vID, vName;

    public String toString() {
        return vID + ": " + vName;
    }
}
