import java.util.LinkedList;
import java.util.Iterator;
public class GraphTraverser {
    AbstractGraph graph;
    public GraphTraverser(AbstractGraph graph) {
        this.graph = graph;
    }
    public OrderedList<TraversedVertex> breadthFirstTraversal() {
        OrderedList<TraversedVertex> result = new OrderedList<>();
        graph.resetNum();
        Iterator vSet = graph.iterator();
        LinkedList<Vertex> queue = new LinkedList<>();
        int i=1;
        Vertex v;
        while (vSet.hasNext()) {
            v = (Vertex)vSet.next();
            if (v.num==0) {
                v.num=i++;
                result.add(new TraversedVertex(v, v.num));
                queue.addLast(v);
                while (!queue.isEmpty()) {
                    v = queue.removeFirst();
                    for (int pos=0; pos<v.adjList.size(); pos++) {
                        Vertex adjV = ((AdjInfo)v.adjList.get(pos)).dest;
                        if (adjV.num==0) {
                            adjV.num=i++;
                            result.add(new TraversedVertex(adjV, adjV.num));
                            queue.addLast(adjV);
                        }
                    }
                }
            }
        }
        return result;
    }
    protected int DFS(Vertex u, int order, OrderedList<TraversedVertex> result) {
        u.num = order;
        result.add(new TraversedVertex(u, order));
        order++;
        OrderedList<AdjInfo> adjList = u.getAdjList();
        for (int pos = 0; pos<u.adjList.size(); pos++) {
            Vertex adjV = ((AdjInfo)adjList.get(pos)).dest;
            if (adjV.num==0) order = DFS(adjV, order, result);
        }
        return order;
    }
    public OrderedList<TraversedVertex> DepthFirstTraversal() {
        graph.resetNum();
        OrderedList<TraversedVertex> result = new OrderedList<>();
        int order = 1;
        Iterator vSet = graph.iterator();
        while(vSet.hasNext()) {
            Vertex u = (Vertex)vSet.next();
            if (u.num==0) order = DFS(u, order, result);
        }
        return result;
    }
}
