import java.util.LinkedList;

public class Path extends LinkedList<Edge> {
    public double pathLen = 0.0;
    public Path() {
        super();
    }
}
