package backtrack_gen_Suggestion;

import java.util.ArrayList;

public class ProductList extends ArrayList<Product> {
    public ProductList() {
        super();
    }
}
